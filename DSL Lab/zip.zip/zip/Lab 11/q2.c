//2. Write a C program to represent directed and undirected graphs using adjacency list.

#include <stdio.h>
#include <stdlib.h>

#define MAX 100

typedef struct Node {
    int vertex;
    struct Node *next;
} Node;

Node* createNode(int v) {
    Node *newNode = (Node*)malloc(sizeof(Node));
    if (newNode == NULL) return NULL;
    newNode->vertex = v;
    newNode->next = NULL;
    return newNode;
}

void addEdge(Node *adjList[], int u, int v, int isDirected) {
    Node *newNode = createNode(v);
    newNode->next = adjList[u];
    adjList[u] = newNode;

    if (!isDirected) {
        newNode = createNode(u);
        newNode->next = adjList[v];
        adjList[v] = newNode;
    }
}

void printGraph(Node *adjList[], int v) {
    for (int i = 0; i < v; i++) {
        Node *temp = adjList[i];
        printf("Vertex %d: ", i);
        while (temp != NULL) {
            printf("-> %d ", temp->vertex);
            temp = temp->next;
        }
        printf("\n");
    }
}

int main(void) {
    int v, e, u, w;

    printf("Enter number of vertices: ");
    scanf("%d", &v);

    Node *adjUndirected[MAX];
    Node *adjDirected[MAX];

    for (int i = 0; i < v; i++) {
        adjUndirected[i] = NULL;
        adjDirected[i] = NULL;
    }

    printf("Enter number of edges: ");
    scanf("%d", &e);

    printf("Enter the edges (u v) for Undirected Graph:\n");
    for (int i = 0; i < e; i++) {
        scanf("%d %d", &u, &w);
        addEdge(adjUndirected, u, w, 0);
    }

    printf("\nUndirected Graph Adjacency List:\n");
    printGraph(adjUndirected, v);

    printf("\nEnter the edges (u v) for Directed Graph:\n");
    for (int i = 0; i < e; i++) {
        scanf("%d %d", &u, &w);
        addEdge(adjDirected, u, w, 1);
    }

    printf("\nDirected Graph Adjacency List:\n");
    printGraph(adjDirected, v);

    return 0;
}

/*
Enter number of vertices: 4
Enter number of edges: 4
Enter the edges (u v) for Undirected Graph:
0 1
0 2
1 2
2 3

Undirected Graph Adjacency List:
Vertex 0: -> 2 -> 1
Vertex 1: -> 2 -> 0
Vertex 2: -> 3 -> 1 -> 0
Vertex 3: -> 2

Enter the edges (u v) for Directed Graph:
0 1
0 2
1 2
2 3

Directed Graph Adjacency List:
Vertex 0: -> 2 -> 1
Vertex 1: -> 2
Vertex 2: -> 3
Vertex 3:
*/
