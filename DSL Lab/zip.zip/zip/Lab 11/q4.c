//4. Write a C program to implement Depth First Search (DFS)

#include <stdio.h>

#define MAX 100

void dfs(int currentVertex, int adj[MAX][MAX], int visited[MAX], int vertices) {
    printf("%d ", currentVertex);
    visited[currentVertex] = 1;

    for (int i = 0; i < vertices; i++) {
        if (adj[currentVertex][i] == 1 && !visited[i]) {
            dfs(i, adj, visited, vertices);
        }
    }
}

int main(void) {
    int v, e, u, w;
    int adj[MAX][MAX] = {0};
    int visited[MAX] = {0};

    printf("Enter number of vertices: ");
    scanf("%d", &v);

    printf("Enter number of edges: ");
    scanf("%d", &e);

    printf("Enter the edges (u v):\n");
    for (int i = 0; i < e; i++) {
        scanf("%d %d", &u, &w);
        adj[u][w] = 1;
        adj[w][u] = 1; // Assuming undirected graph for DFS
    }

    int startNode;
    printf("Enter starting vertex for DFS: ");
    scanf("%d", &startNode);

    printf("DFS Traversal: ");
    dfs(startNode, adj, visited, v);
    printf("\n");

    return 0;
}

/*
Enter number of vertices: 5
Enter number of edges: 5
Enter the edges (u v):
0 1
0 2
1 3
1 4
2 4
Enter starting vertex for DFS: 0
DFS Traversal: 0 1 3 4 2
*/
