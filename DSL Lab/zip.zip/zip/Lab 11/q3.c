//3. Write a C program to implement Breadth First Search (BFS)

#include <stdio.h>

#define MAX 100

void bfs(int adj[MAX][MAX], int vertices, int startVertex) {
    int visited[MAX] = {0};
    int queue[MAX];
    int front = 0, rear = 0;

    visited[startVertex] = 1;
    queue[rear++] = startVertex;

    printf("BFS Traversal: ");

    while (front < rear) {
        int currentVertex = queue[front++];
        printf("%d ", currentVertex);

        for (int i = 0; i < vertices; i++) {
            if (adj[currentVertex][i] == 1 && !visited[i]) {
                visited[i] = 1;
                queue[rear++] = i;
            }
        }
    }
    printf("\n");
}

int main(void) {
    int v, e, u, w;
    int adj[MAX][MAX] = {0};

    printf("Enter number of vertices: ");
    scanf("%d", &v);

    printf("Enter number of edges: ");
    scanf("%d", &e);

    printf("Enter the edges (u v):\n");
    for (int i = 0; i < e; i++) {
        scanf("%d %d", &u, &w);
        adj[u][w] = 1;
        adj[w][u] = 1; // Assuming undirected graph for BFS
    }

    int startNode;
    printf("Enter starting vertex for BFS: ");
    scanf("%d", &startNode);

    bfs(adj, v, startNode);

    return 0;
}

/*
Enter number of vertices: 5
Enter number of edges: 5
Enter the edges (u v):
0 1
0 2
1 3
1 4
2 4
Enter starting vertex for BFS: 0
BFS Traversal: 0 1 2 3 4
*/
