//1. Write a C program to represent directed and undirected graphs using adjacency matrix.

#include <stdio.h>

#define MAX 100

int main(void) {
    int v, e, u, w;
    int adj[MAX][MAX];

    printf("Enter number of vertices: ");
    scanf("%d", &v);

    for (int i = 0; i < v; i++) {
        for (int j = 0; j < v; j++) {
            adj[i][j] = 0;
        }
    }

    printf("Enter number of edges: ");
    scanf("%d", &e);

    printf("Enter the edges (u v) for Undirected Graph:\n");
    for (int i = 0; i < e; i++) {
        scanf("%d %d", &u, &w);
        adj[u][w] = 1;
        adj[w][u] = 1;
    }

    printf("Undirected Graph Adjacency Matrix:\n");
    for (int i = 0; i < v; i++) {
        for (int j = 0; j < v; j++) {
            printf("%d ", adj[i][j]);
        }
        printf("\n");
    }

    for (int i = 0; i < v; i++) {
        for (int j = 0; j < v; j++) {
            adj[i][j] = 0;
        }
    }

    printf("\nEnter the edges (u v) for Directed Graph:\n");
    for (int i = 0; i < e; i++) {
        scanf("%d %d", &u, &w);
        adj[u][w] = 1;
    }

    printf("Directed Graph Adjacency Matrix:\n");
    for (int i = 0; i < v; i++) {
        for (int j = 0; j < v; j++) {
            printf("%d ", adj[i][j]);
        }
        printf("\n");
    }

    return 0;
}
/*
Enter number of vertices: 4
Enter number of edges: 4
Enter the edges (u v) for Undirected Graph:
0 1
0 2
1 2
2 3
Undirected Graph Adjacency Matrix:
0 1 1 0
1 0 1 0
1 1 0 1
0 0 1 0

Enter the edges (u v) for Directed Graph:
0 1
0 2
1 2
2 3
Directed Graph Adjacency Matrix:
0 1 1 0
0 0 1 0
0 0 0 1
0 0 0 0
*/
