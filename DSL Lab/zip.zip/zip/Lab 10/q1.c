//1. Write a program to create a BST and perform inorder, preorder, and postorder traversals.
//2. Write a function to search an element in a BST.
//3. Write a function to delete a node from a BST.
//4. Write a function to find the minimum and maximum elements in a BST.

#include <stdio.h>
#include <stdlib.h>

// Define the BST node structure
typedef struct Node {
    int data;
    struct Node *left;
    struct Node *right;
} Node;

// Create a new node (simple check without exit())
Node* createNode(int data) {
    Node *newNode = (Node*)malloc(sizeof(Node));
    if (newNode == NULL) {
        printf("Memory allocation failed!\n");
        return NULL;
    }
    newNode->data = data;
    newNode->left = NULL;
    newNode->right = NULL;
    return newNode;
}

// 1. Insert a node into the BST
Node* insert(Node *root, int data) {
    if (root == NULL) return createNode(data);

    if (data < root->data) {
        root->left = insert(root->left, data);
    } else if (data > root->data) {
        root->right = insert(root->right, data);
    }
    return root;
}

// 1. Traversals
void inorder(Node *root) {
    if (root != NULL) {
        inorder(root->left);
        printf("%d ", root->data);
        inorder(root->right);
    }
}

void preorder(Node *root) {
    if (root != NULL) {
        printf("%d ", root->data);
        preorder(root->left);
        preorder(root->right);
    }
}

void postorder(Node *root) {
    if (root != NULL) {
        postorder(root->left);
        postorder(root->right);
        printf("%d ", root->data);
    }
}

// 2. Search an element in the BST
Node* search(Node *root, int key) {
    if (root == NULL || root->data == key) {
        return root;
    }
    if (key < root->data) {
        return search(root->left, key);
    }
    return search(root->right, key);
}

// 4. Find the minimum element in the BST
Node* findMin(Node *root) {
    Node *current = root;
    while (current && current->left != NULL) {
        current = current->left;
    }
    return current;
}

// 4. Find the maximum element in the BST
Node* findMax(Node *root) {
    Node *current = root;
    while (current && current->right != NULL) {
        current = current->right;
    }
    return current;
}

// 3. Delete a node from the BST
Node* deleteNode(Node *root, int key) {
    if (root == NULL) return root;

    if (key < root->data) {
        root->left = deleteNode(root->left, key);
    } else if (key > root->data) {
        root->right = deleteNode(root->right, key);
    } else {
        // Node with only one child or no child
        if (root->left == NULL) {
            Node *temp = root->right;
            free(root);
            return temp;
        } else if (root->right == NULL) {
            Node *temp = root->left;
            free(root);
            return temp;
        }

        // Node with two children: Get the inorder successor (smallest in right subtree)
        Node *temp = findMin(root->right);

        // Copy the inorder successor's content to this node
        root->data = temp->data;

        // Delete the inorder successor
        root->right = deleteNode(root->right, temp->data);
    }
    return root;
}

int main(void) {
    Node *root = NULL;

    // Creating the BST by inserting elements
    int values[] = {50, 30, 20, 40, 70, 60, 80};
    int n = sizeof(values) / sizeof(values[0]);

    for (int i = 0; i < n; i++) {
        root = insert(root, values[i]);
    }

    printf("--- Traversals ---\n");
    printf("Inorder:   "); inorder(root); printf("\n");
    printf("Preorder:  "); preorder(root); printf("\n");
    printf("Postorder: "); postorder(root); printf("\n\n");

    // Min and Max
    Node *minNode = findMin(root);
    Node *maxNode = findMax(root);
    if (minNode) printf("Minimum Element: %d\n", minNode->data);
    if (maxNode) printf("Maximum Element: %d\n", maxNode->data);

    // Search
    int key = 40;
    Node *found = search(root, key);
    if (found) {
        printf("Element %d found in the BST.\n", key);
    } else {
        printf("Element %d not found in the BST.\n", key);
    }

    // Delete a node
    printf("\nDeleting node 30...\n");
    root = deleteNode(root, 30);

    printf("Inorder after deletion: ");
    inorder(root);
    printf("\n");

    return 0;
}
/*
--- Traversals ---
Inorder:   20 30 40 50 60 70 80
Preorder:  50 30 20 40 70 60 80
Postorder: 20 40 30 60 80 70 50

Minimum Element: 20
Maximum Element: 80
Element 40 found in the BST.

Deleting node 30...
Inorder after deletion: 20 40 50 60 70 80
*/
